package JavaExc.T3Question11_12_13.GAME.GameQ11;
/**
 * Created by TTPLkn on 11-08-2020.
 */
public class Player {
    int id;
    String name;
    int power;
    int health;//in percentage
    Player(int id, String name, int power, int health){
        this.id = id;
        this.name = name;
        this.power = power;
        this.health = health;
    }
    public Player() {
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getPower() {
        return power;
    }

    public int getHealth() {
        return health;
    }
}

