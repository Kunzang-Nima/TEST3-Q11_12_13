package JavaExc.T3Question11_12_13.GAME.GameQ11;
/**
 * Created by TTPLkn on 16-08-2020.
 */
class YoungPlayer extends  Player{
    public YoungPlayer(int id, String name, int power, int health) {
        this.id = id;
        this.name = name;
        this.power = power;
        this.health = health;
    }
}
