package JavaExc.T3Question11_12_13.GAME.GameQ11;

import java.util.*;
/**
 * Created by TTPLkn on 11-08-2020.
 */
public class Battle {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);//input from the system
        Random rand = new Random();
        System.out.println("************************");
        System.out.println("* WELCOME TO BATTLE!!! *");
        System.out.println("************************");
        boolean running = true;
        GAME:
        //labeling this while loop
        while (running) {
            List<Player> playerRegistrationList = new ArrayList<>();
            Player tempPlayer;
            System.out.print("Enter number of players : ");
            int n = in.nextInt();
            int noRound = Math.getExponent(n);
            if (n % 2 == 0 && n > 0) {//checks player count is greater than zero and it is exactly divisible by 2
                for (int i = 0; i < n; i++) {//this loop registers the player in list
                    System.out.println("Enter Player " + (i + 1) + " Details:\n----------------------");
                    tempPlayer = PlayerRegistration();
                    playerRegistrationList.add(tempPlayer);
                }
                for (int k = 0; k < playerRegistrationList.size(); k++) {
                    System.out.print("PlayerID: " + playerRegistrationList.get(k).getId() + "  | Player Name: " + playerRegistrationList.get(k).getName() + "  | Power: " + playerRegistrationList.get(k).getPower() + "  | Heath: " + playerRegistrationList.get(k).getHealth());
                    int strength = playerRegistrationList.get(k).getPower() + playerRegistrationList.get(k).getHealth();
                    if (strength > 120 && strength < 130)
                        System.out.println(" (Strong Player) " + strength);
                    else if (strength > 110 && strength < 120)
                        System.out.println(" (Healthy Player) " + strength);
                    else if (strength > 100 && strength < 110)
                        System.out.println(" (Young Player) " + strength);
                    else
                        System.out.println(" (Old Player) " + strength);
                }
                List<Player> sortedPlayerList = new ArrayList<>();
                //int ch = 0;
                int numBat = n / 2;
                Player winner;
                List<Player> winnerList = new ArrayList<>();
                Player tempWin;
                for (int j = 1; j <= noRound; j++) {
                    tournamentFixture(n, playerRegistrationList, sortedPlayerList);
                    System.out.println("\nTOURNAMENT ROUND " + (j));
                    //if (numBat == 1) {
                    if (n / 2 == 1) {
                        if (noRound == 1) {
                            System.out.println("No need of triggering or entering battle number as it has/left only 2 player, so there will be only one match..\n");
                        } else {
                            System.out.print("   # WINNER OF FINAL ROUND #");
                        }
                        if (j > 1) {
                            Random ra = new Random();
                            while (sortedPlayerList.get(0).getHealth() < 40 && sortedPlayerList.get(1).getHealth() < 40) {
                                System.out.println("\n\tWhat would you like to do?");
                                System.out.println("\t1. Drink health and power potion");
                                System.out.println("\t2. Resume Battle");
                                int inchoic = in.nextInt();
                                if (inchoic == 1) {
                                    int powerBoost = ra.nextInt((15 + 1) - 10) + 10;
                                    int healthBoost = ra.nextInt((50 + 1) - 30) + 30;
                                    for (int i = 0; i < 2; i++) {
                                        int p = sortedPlayerList.get(i).getPower() + powerBoost;
                                        int h = sortedPlayerList.get(i).getHealth() + healthBoost;
                                        System.out.println("Health potion of PlayerID: " + sortedPlayerList.get(i).getId() + " after boost is " + h);
                                        System.out.println("Power potion after boost is " + p);
                                        sortedPlayerList.add(new Player(sortedPlayerList.get(i).getId(), sortedPlayerList.get(i).getName(), p, h));
                                    }


                                } else if (inchoic == 2) {
                                    break;
                                }
                            }
                        }
                        winner = fight(sortedPlayerList.get(0), sortedPlayerList.get(1));
                        System.out.print("ID: " + winner.getId());
                        System.out.print(", Name: " + winner.getName());
                        System.out.print(" is     ***WINNER!***  \n");
                        System.out.println("Health potion left " + winner.getHealth());
                        System.out.println("Power potion left " + winner.getPower());
                        winnerList.add(winner);
                        System.out.println("#######################");
                        System.out.println("# THANKS FOR PLAYING! #");
                        System.out.println("#######################");
                        break;
                        //} else if (numBat >= 2) {//n/2 > 1) if the pairs are more than one\
                    } else if ((n / 2) > 1) {//n/2 > 1) if the pairs are more than one\
                        for (int i = 0; i < (sortedPlayerList.size() / 2); i++) {
                            System.out.println("------------------------------------------------");
                            System.out.println("Enter 1,2,3... to choose BATTLE to fight. ");
                            int ch = in.nextInt();
                            if (ch <= (sortedPlayerList.size() / 2)) {
                                if (j > 1) {
                                    Random ra = new Random();
                                    while (sortedPlayerList.get(0).getHealth() < 40 && sortedPlayerList.get(1).getHealth() < 40) {
                                        System.out.println("\n\tWhat would you like to do?");
                                        System.out.println("\t1. Drink health and power potion");
                                        System.out.println("\t2. Resume Battle");
                                        int inchoic = in.nextInt();
                                        if (inchoic == 1) {
                                            int powerBoost = ra.nextInt((15 + 1) - 10) + 10;
                                            int healthBoost = ra.nextInt((50 + 1) - 30) + 30;
                                            for (int k = 0; k < 2; k++) {
                                                int p = sortedPlayerList.get(k).getPower() + powerBoost;
                                                int h = sortedPlayerList.get(k).getHealth() + healthBoost;
                                                System.out.println("Health potion of PlayerID: " + sortedPlayerList.get(k).getId() + " after boost is " + h);
                                                System.out.println("Power potion after boost is " + p);
                                                sortedPlayerList.add(new Player(sortedPlayerList.get(k).getId(), sortedPlayerList.get(k).getName(), p, h));
                                            }
                                        } else if (inchoic == 2) {
                                            break;
                                        } else ;
                                    }

                                }
                                tempWin = fight(sortedPlayerList.get(ch - 1), sortedPlayerList.get(ch));
                                System.out.print("ID: " + tempWin.getId());
                                System.out.print(", Name: " + tempWin.getName());
                                System.out.print(" is ### WINNER! ###\n");
                                System.out.println("Health potion left " + tempWin.getHealth());
                                System.out.println("Power potion left " + tempWin.getPower());
                                winnerList.add(tempWin);
                            }
                            else if(ch>(sortedPlayerList.size() / 2)){
                                break;
                            }
                            //if ((sortedPlayerList.size()/2)<2){break;
                        }

                        /*for (int i = 0; i < winnerList.size(); i++) {
                            System.out.println("PlayerID: " + winnerList.get(i).getId() + "  | Player Name: " + winnerList.get(i).getName() + "  | Power: " + winnerList.get(i).getPower() + "  | Heath: " + winnerList.get(i).getHealth());
                        }*/
                        playerRegistrationList = winnerList;
                        sortedPlayerList = winnerList;
                        n = winnerList.size();

                    } else ;
                }
            } else {
                System.out.println("Invalid player count! Enter even number as the battle is between two person the player count must be even and 2 or more");
            }
        }
    }

    //method to fight
    public static Player fight(Player player1, Player player2) {
        Random ra = new Random();
        int MaxPower = 5;//max power at a time to reduce its power while fighting
        int player1Power = player1.getPower();
        int player1Health = player1.getHealth();
        int player2Power = player2.getPower();
        int player2Health = player2.getHealth();
        long startTime = System.nanoTime();
        while (player1Power > 5 && player2Power > 5) {
            int powerDecrement1 = ra.nextInt(MaxPower);
            player1Power = player1Power - powerDecrement1;
            int powerDecrement2 = ra.nextInt(MaxPower);
            player2Power = player2Power - powerDecrement2;
        }
        long stopTime = System.nanoTime();

        if (player1Power > player2Power) {
            int powerDamagedDifPlayer1 = player1.getPower() - player1Power;
            double dmgPercent1 = (double) powerDamagedDifPlayer1 / player1.getPower();
            player1Health = (int) (player1Health - player1Health * dmgPercent1);
            //System.out.println("Health potion left " + player1Health);
            System.out.println("This battle took "+(stopTime - startTime)+" Nanoseconds");
            player1 = new Player(player1.getId(), player1.getName(), player1Power, player1Health);
            return player1;
        } else {
            int powerDamagedDifPlayer2 = player2.getPower() - player2Power;
            double dmgPercent2 = (double) powerDamagedDifPlayer2 / player2.getPower();
            player2Health = (int) (player2Health - player2Health * dmgPercent2);
            System.out.println("This battle took "+(stopTime - startTime)+" Nanoseconds");
            //System.out.println("Health potion left " + player2Health);
            player2 = new Player(player2.getId(), player2.getName(), player2Power, player2Health);
            return player2;
        }
    }

    //player registration method
    public static Player PlayerRegistration() {
        Random rand = new Random();
        Player playerReg;
        int id;
        String name;
        int power;
        int health;
        //int maxPower = 75;
        //int maxHealth = 100;//percentage
        Scanner input = new Scanner(System.in);
        System.out.print("Enter ID:");
        id = input.nextInt();
        input.nextLine();//this line is add not escape next input due to nextInt
        System.out.print("Enter Name:");
        name = input.nextLine();
        //power = rand.nextInt(maxPower);
        //health = rand.nextInt(maxHealth);
        /*Random foo = new Random();
        int randomNumber = foo.nextInt((max + 1) - min) + min;*/
        //System.out.println("Enter POWER Between 20-30");
        power = rand.nextInt((30 + 1) - 20) + 20;
        //System.out.println("Enter HEALTH Between 70 - 100");
        health = rand.nextInt((100 + 1) - 70) + 70;

        if ((power + health) > 120 && (power + health) < 130)
            playerReg = new StrongPlayer(id, name, power, health);
        else if ((power + health) > 110 && (power + health) < 120)
            playerReg = new HealthyPlayer(id, name, power, health);
        else if ((power + health) > 100 && (power + health) < 110)
            playerReg = new YoungPlayer(id, name, power, health);
        else
            playerReg = new OldPlayer(id, name, power, health);
        return playerReg;
    }

    public static void tournamentFixture(int n, List<Player> playerRegistrationList, List<Player> sortedPlayerList) {
        System.out.println("\nGame fixture are drawn based on their health\n--------------------------------------------");
        int playerHealth[] = new int[n];
        for (int i = 0; i < n; i++) {
            playerHealth[i] = playerRegistrationList.get(i).getHealth();
        }
            /*System.out.println("Before health sort");
            for (int i : playerHealth) {
                System.out.print(i + " ");
            }
            System.out.println();*/
        for (int j = 1; j < n; j++) {
            int key = playerHealth[j];
            int i = j - 1;
            while ((i > -1) && (playerHealth[i] > key)) {
                playerHealth[i + 1] = playerHealth[i];
                i--;
            }
            playerHealth[i + 1] = key;
        }
                /*System.out.println("After health sort");
                for (int i : playerHealth) {
                    System.out.print(i + " ");
                }
                System.out.println();*/
        System.out.println("The tournaments are between\n---------------------------");
        int tcount = 0;
        Player player[] = new Player[n / 2];//array for battle pool
        if (n > 2) {//checks players are more than 2
            for (int i = 0; i < n; i = i + 2) {
                tcount++;//counts loop for battle to find the each battle
                Player p = null, p1 = null;
                System.out.print("Battle: " + tcount + ")\n--------- ");
                for (int j = 0; j < n; j++) {
                    if (playerHealth[i] == playerRegistrationList.get(j).getHealth()) {
                        System.out.print("PlayerID: " + playerRegistrationList.get(j).getId() + ", Name: " + playerRegistrationList.get(j).getName());
                        //p= playerRegistrationList.get(j);
                        sortedPlayerList.add(playerRegistrationList.get(j));
                        break;
                    }
                }
                for (int k = 0; k < n; k++) {
                    if (playerHealth[i + 1] == playerRegistrationList.get(k).getHealth()) {
                        System.out.println("   VS   PlayerID: " + playerRegistrationList.get(k).getId() + ", Name: " + playerRegistrationList.get(k).getName());
                        sortedPlayerList.add(playerRegistrationList.get(k));
                        break;
                    }
                }
            }
        } else {//if players are exactly 2
            for (int i = 0; i < 2; i++) {//when the battle is only one
                System.out.print("The battle is between | PlayerID: " + playerRegistrationList.get(i).getId() + ", Name: " + playerRegistrationList.get(i).getName());
                System.out.println("   VS   PlayerID: " + playerRegistrationList.get(i + 1).getId() + ", Name: " + playerRegistrationList.get(i + 1).getName());
                sortedPlayerList.add(playerRegistrationList.get(i));
                sortedPlayerList.add(playerRegistrationList.get(i + 1));
                break;
            }
        }
    }
}
