package JavaExc.T3Question11_12_13.GAME.ExpressCalQ13;
import java.util.Scanner;
/**
 * Created by TTPLkn on 18-08-2020.
 */
public class ExpressionCalculator {
    public static void main(String[] args) {
        Scanner inputExp = new Scanner(System.in);
        System.out.println("ENTER MATHEMATICAL EXPRESSION:");
        String exp = inputExp.nextLine();//13*5-20+2*4
        if (exp.contains(" ")) {
            System.out.println("Invalid input! white space");
        } else {
            calculate(exp);
        }
        inputExp.close();
    }

    public static void calculate(String exp) {
        String b = "";
        String d = "";
        String m = "";
        String a = "";
        String s = "";
        b = d = m = a = s = exp;
        if (d.contains("(")) {
            b = d = m = a = s = new ExpressionCalculator().bracket(b);
        }
        if (d.contains("/")) {
            d = m = a = s = new ExpressionCalculator().divide(d);
        }
        if (m.contains("*")) {
            d = m = a = s = new ExpressionCalculator().multiply(m);//13*5-20+2*4
        }
        if (exp.contains("+")) {
            d = m = a = s = new ExpressionCalculator().add(a);//65-20+8
        }
        if (exp.contains("-")) {//65-28
            d = m = a = s = new ExpressionCalculator().subtract(s);//37
        }
        System.out.println("Value of an expression: " + exp + "\n" + s);//37
    }
    //method for expression with bracket
    private String bracket(String b) {//(3+2)
        String expB = b;//(3-2)
        for (int i = 0; i < expB.length(); i++) {
            if (expB.charAt(i) == '(') {//i=0
                char operation = 0;
                for (int j = (i + 1); j < expB.length(); j++) {//j=(0+1)
                    char sign = expB.charAt(j);//j=1 is 3
                    switch (sign) {
                        case '+':
                            operation = sign;
                            expB = expB.replace("(" + leftValue(j, expB) + operation + rightValue(j, expB) + ")",
                                    String.valueOf(Integer.parseInt(leftValue(j, expB))
                                            + Integer.parseInt(rightValue(j, expB))));
                            break;
                        case '-':
                            operation = sign;
                            expB = expB.replace("(" + leftValue(j, expB) + operation + rightValue(j, expB) + ")",
                                    String.valueOf(Integer.parseInt(leftValue(j, expB))
                                            - Integer.parseInt(rightValue(j, expB))));
                            break;
                        case '/':
                            operation = sign;
                            expB = expB.replace("(" + leftValue(j, expB) + operation + rightValue(j, expB) + ")",
                                    String.valueOf(Integer.parseInt(leftValue(j, expB))
                                            / Integer.parseInt(rightValue(j, expB))));
                            break;
                        case '*':
                            operation = sign;
                            expB = expB.replace("(" + leftValue(j, expB) + operation + rightValue(j, expB) + ")",
                                    String.valueOf(Integer.parseInt(leftValue(j, expB))
                                            * Integer.parseInt(rightValue(j, expB))));
                            break;
                    }
                }
            }
        }
        return expB;
    }

    //divide method
    private String divide(String s) {
        String expD = s;
        for (int i = 0; i < expD.length(); i++) {
            if (expD.charAt(i) == '/') {//24/2
                expD = expD.replace(leftValue(i, expD) + "/" + rightValue(i, expD),
                        String.valueOf(Integer.parseInt(leftValue(i, expD))
                                / Integer.parseInt(rightValue(i, expD))));
            }
        }
        return expD;
    }

    //multiplication method
    private String multiply(String s) { // 13*5-20+2*4
        String expM = s;  // 13*5-20+2*4 | 65-20+2*4 | 65-20+8
        for (int i = 0; i < expM.length(); i++) {
            if (expM.charAt(i) == '*') {
                expM = expM.replace(leftValue(i, expM) + "*" + rightValue(i, expM),
                        String.valueOf(Integer.parseInt(leftValue(i, expM)) * Integer.parseInt(rightValue(i, expM))));
            }
        }
        return expM;//65-20+2*4 | 65-20+8
    }

    //Addition method
    private String add(String s) {//65-20+8
        String expA = s;//65-20+8
        for (int i = 0; i < expA.length(); i++) {//i=5
            if (expA.charAt(i) == '+') {
                expA = expA.replace(leftValue(i, expA) + "+" + rightValue(i, expA),
                        String.valueOf(Integer.parseInt(leftValue(i, expA))
                                + Integer.parseInt(rightValue(i, expA))));
            }
        }
        return expA; //65-28
    }

    //Subtraction method
    private String subtract(String s) {//65-28
        String expS = s;  //65-28
        for (int i = 0; i < expS.length(); i++) {//i=2;
            if (expS.charAt(i) == '-') {
                expS = expS.replace(leftValue(i, expS) + "-" + rightValue(i, expS),
                        String.valueOf(Integer.parseInt(leftValue(i, expS))
                                - Integer.parseInt(rightValue(i, expS))));
            }
        }
        return expS;//expS = 37
    }

    //method to get Left values
    public static String leftValue(int i, String exp) {// i=2,  exp=13*5-20+2*4 //i=7 exp=65-20+2*4 // i=5 exp=65-20+8 //i=2 exp=65-28
        String leftV = "";
        for (int j = (i - 1); j >= 0; j--) {//i=2, j=(2-1) | i=7, j=(7-1) | i=5, j=5-1 | i=2, j=1
            char lv = exp.charAt(j);//j=1 is 3, j=0 is 1.| j=6 is 2 | j=4 is 0, j=3 is 2 | j=1 is 5, j=0=6
            if (lv == '+' || lv == '*' || lv == '-' || lv == '/' || lv == '(' || lv == ')') {
                break;
            }
            leftV = exp.charAt(j) + leftV;//13, 2, 20, 65
        }
        return leftV;//13, 2, 20, 65
    }

    //method to get right values
    public static String rightValue(int i, String expR) { //i=2,  exp=13*5-20+2*4 //i=7 exp=65-20+2*4 // i=5 exp=65-20+8 //i=2 exp=65-28
        String rightValue = "";//right value 5
        for (int j = (i + 1); j < expR.length(); j++) {//i=2, j=(2+1) |i=7, j=(7+1) | i=5, j=(5+1) |i=2, j=(2+1)
            char rv = expR.charAt(j);//j=3 is 5 |j=8 is 4 |j=6 is 8    |j=3 is 2, j=4 is 8
            if (rv == '+' || rv == '*' || rv == '-' || rv == '/' || rv == '(' || rv == ')') {
                break;
            }
            rightValue = rightValue + expR.charAt(j); //2
        }
        return rightValue;//return with 5 | return with 4 | return with 8 | return with 28
    }
}
