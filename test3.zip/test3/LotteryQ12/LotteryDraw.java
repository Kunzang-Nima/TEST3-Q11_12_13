package JavaExc.T3Question11_12_13.GAME.LotteryQ12;
import java.util.*;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
/**
 * Created by TTPLkn on 16-08-2020.
 */
public class LotteryDraw {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static Random ran = new Random();
    public static Scanner input = new Scanner(System.in);


    public static void main(String args[]) {
        int ch;
        int n = 0;
        //boolean run = true;
        int rounds = 0;
        //List<Integer> playerList = new ArrayList<>();
        //List<Integer> luckyNoList = new ArrayList<>();
        System.out.println("|| WELCOME TO LOTTERY DRAW ||");
        System.out.println("*****************************");
        do {
            dashboard();
            ch = input.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("TO SELECT Nth RANDOM PLAYERS");
                    System.out.println("----------------------------");
                    System.out.println("Enter number of players for lottery draw? ");
                    n = input.nextInt();
                    //ArrayList<Integer> playerNoList = new ArrayList<>();
                    for (int i = 0; i < n; i++) {
                        System.out.print("PlayerId: " + (i + 1) + "  " + getPlayerList(n).get(i).getPlayerNoList());
                        System.out.println();
                        //playerNoList.add(new Random().nextInt(1000));
                    }
                    System.out.println("Random selection numbers for each of players completed ! \n");
                    break;
                case 2:
                    System.out.println("LUCKY DRAW for the Lottery...");
                    System.out.println("----------------------------");
                    /*if (playerList.isEmpty() || (n < 1)) {
                        System.out.println(ANSI_RED + "Empty players! First insert/select players with option 1. \n" + ANSI_RESET);
                    } else {
                        for (int i = 0; i < playerList.size(); i++) {
                            System.out.println("PLAYER " + playerList.get(i));
                        }
                    }*/
                    while (ch != 0) {
                        List<LotteryPlayer> playerRandomList = getPlayerList(n);
                        for (int i = 0; i < playerRandomList.size(); i++) {
                            int random = ran.nextInt(10) + 0;
                            for (int j = 0; j < playerRandomList.get(i).playerNoList.size(); j++) {
                                if (random == playerRandomList.get(i).playerNoList.get(j)) {
                                    playerRandomList.get(i).playerNoList.remove(j);
                                    rounds++;
                                }
                                if (playerRandomList.get(i).playerNoList.isEmpty()) {
                                    System.out.println("WINNER IS player with ID: " + playerRandomList.get(i).playerId);
                                    ch = 0;
                                }
                            }
                        }
                    }
                    System.out.println("The total round took to empty one of the list is  : " + rounds);
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println(ANSI_RED + "Invalid option entered, Enter option within bound\n" + ANSI_RESET);
                    break;
            }
        }
        while (ch > 0);
    }
    //random listing method
    /*private static Set<Integer> randomList() {
        Set<Integer> playerLists = new LinkedHashSet<>();
        Set<Integer> playerList = new LinkedHashSet<>();
        Integer player;
        while (playerLists.size() < 10) {
            playerLists.add(new Integer(ran.nextInt(1000) + 0));
        }
        for (Integer i : playerLists) {
            int p = i;
            playerList.add( new Integer(p));
        }
        return playerList;
    }*/

    public static ArrayList<Integer> randomList() {
        ArrayList<Integer> playerNoList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            playerNoList.add(new Integer(ran.nextInt(10) + 0));
        }
        return playerNoList;
    }

    public static ArrayList<LotteryPlayer> getPlayerList(int n) {
        ArrayList<LotteryPlayer> playerNoList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            LotteryPlayer addToList = new LotteryPlayer((i + 1), randomList());
            playerNoList.add(addToList);
        }
        return playerNoList;
    }

    //dashboard option method
    private static void dashboard() {
        System.out.println("*SELECT BELLOW OPTION IN SEQUENCE TO DRAW LOTTERY*");
        System.out.println("\t1.  Get nth random players with 10 random numbers ? ");
        System.out.println("\t2.  Display nth players. ");
        System.out.println("\t3.  Exit the lottery draw! ");
    }
}
