package JavaExc.T3Question11_12_13.GAME.LotteryQ12;
import java.util.ArrayList;
/**
 * Created by TTPLkn on 18-08-2020.
 */
public class LotteryPlayer {
    int playerId;
    ArrayList<Integer> playerNoList;
    public LotteryPlayer(int playerId, ArrayList<Integer> playerNoList) {
        this.playerId = playerId;
        this.playerNoList = playerNoList;
    }

    public int getPlayerId() {
        return playerId;
    }

    public ArrayList<Integer> getPlayerNoList() {
        return playerNoList;
    }
}
